const STATUS_ACTIVE = "active"
const STATUS_INACTIVE = "inactive"
const TOKEN_KEY = "5xVpMrXK6g"
const AWS_ACCESS_KEY_ID = "AKIA5NZ245NVFBKOMU4K"
const AWS_SECRET_ACCESS_KEY = "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"

module.exports = {
    STATUS_ACTIVE, 
    STATUS_INACTIVE, 
    TOKEN_KEY,
    AWS_ACCESS_KEY_ID,
    AWS_SECRET_ACCESS_KEY
}